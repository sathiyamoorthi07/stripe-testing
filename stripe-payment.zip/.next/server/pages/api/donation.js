"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/donation";
exports.ids = ["pages/api/donation"];
exports.modules = {

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "next-connect":
/*!*******************************!*\
  !*** external "next-connect" ***!
  \*******************************/
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ }),

/***/ "(api)/./src/middleware/db-middleware.ts":
/*!*****************************************!*\
  !*** ./src/middleware/db-middleware.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ dbMiddleware)\n/* harmony export */ });\n/* harmony import */ var _utils_db_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/utils/db-connect */ \"(api)/./src/utils/db-connect.ts\");\n\nasync function dbMiddleware(req, res, next) {\n    try {\n        req.dbConn = await (0,_utils_db_connect__WEBPACK_IMPORTED_MODULE_0__[\"default\"])();\n    } catch (error) {\n        //console.log(\"DB Exception\", error?.message);\n        res.write(error?.message);\n        return res.end();\n    }\n    next();\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9zcmMvbWlkZGxld2FyZS9kYi1taWRkbGV3YXJlLnRzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQTJDO0FBRTVCLGVBQWVDLGFBQzVCQyxHQUFRLEVBQ1JDLEdBQW9CLEVBQ3BCQyxJQUFTO0lBRVQsSUFBSTtRQUNGRixJQUFJRyxNQUFNLEdBQUcsTUFBTUwsNkRBQVNBO0lBQzlCLEVBQUUsT0FBT00sT0FBWTtRQUNuQiw4Q0FBOEM7UUFDOUNILElBQUlJLEtBQUssQ0FBQ0QsT0FBT0U7UUFDakIsT0FBT0wsSUFBSU0sR0FBRztJQUNoQjtJQUVBTDtBQUNGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vc3RyaXBlLXBheW1lbnQvLi9zcmMvbWlkZGxld2FyZS9kYi1taWRkbGV3YXJlLnRzPzk0NTQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGRiQ29ubmVjdCBmcm9tIFwiQC91dGlscy9kYi1jb25uZWN0XCI7XHJcbmltcG9ydCB7IE5leHRBcGlSZXNwb25zZSB9IGZyb20gXCJuZXh0XCI7XHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGRiTWlkZGxld2FyZShcclxuICByZXE6IGFueSxcclxuICByZXM6IE5leHRBcGlSZXNwb25zZSxcclxuICBuZXh0OiBhbnlcclxuKSB7XHJcbiAgdHJ5IHtcclxuICAgIHJlcS5kYkNvbm4gPSBhd2FpdCBkYkNvbm5lY3QoKTtcclxuICB9IGNhdGNoIChlcnJvcjogYW55KSB7XHJcbiAgICAvL2NvbnNvbGUubG9nKFwiREIgRXhjZXB0aW9uXCIsIGVycm9yPy5tZXNzYWdlKTtcclxuICAgIHJlcy53cml0ZShlcnJvcj8ubWVzc2FnZSk7XHJcbiAgICByZXR1cm4gcmVzLmVuZCgpO1xyXG4gIH1cclxuXHJcbiAgbmV4dCgpO1xyXG59XHJcbiJdLCJuYW1lcyI6WyJkYkNvbm5lY3QiLCJkYk1pZGRsZXdhcmUiLCJyZXEiLCJyZXMiLCJuZXh0IiwiZGJDb25uIiwiZXJyb3IiLCJ3cml0ZSIsIm1lc3NhZ2UiLCJlbmQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./src/middleware/db-middleware.ts\n");

/***/ }),

/***/ "(api)/./src/models/donation-model-schema.ts":
/*!*********************************************!*\
  !*** ./src/models/donation-model-schema.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst DonationModelSchema = new mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema({\n    zone_id: {\n        type: mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema.Types.ObjectId\n    },\n    type: {\n        type: mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema.Types.String\n    },\n    currency: {\n        type: mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema.Types.String\n    },\n    amount: {\n        type: mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema.Types.String\n    },\n    status: {\n        type: mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema.Types.String,\n        default: \"ENABLE\"\n    },\n    created_at: {\n        type: mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema.Types.Date,\n        default: new Date()\n    },\n    updated_at: {\n        type: mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema.Types.Date,\n        default: new Date()\n    },\n    product_id: {\n        type: mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema.Types.String\n    },\n    price_id: {\n        type: mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema.Types.String\n    }\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mongoose__WEBPACK_IMPORTED_MODULE_0__.models.donation || (0,mongoose__WEBPACK_IMPORTED_MODULE_0__.model)(\"donation\", DonationModelSchema));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9zcmMvbW9kZWxzL2RvbmF0aW9uLW1vZGVsLXNjaGVtYS50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBZ0Y7QUFnQmhGLE1BQU1HLHNCQUFzQixJQUFJSCw0Q0FBTUEsQ0FBMkI7SUFDL0RJLFNBQVM7UUFBRUMsTUFBTUwsNENBQU1BLENBQUNNLEtBQUssQ0FBQ0MsUUFBUTtJQUFDO0lBQ3ZDRixNQUFNO1FBQUVBLE1BQU1MLDRDQUFNQSxDQUFDTSxLQUFLLENBQUNFLE1BQU07SUFBQztJQUNsQ0MsVUFBVTtRQUFFSixNQUFNTCw0Q0FBTUEsQ0FBQ00sS0FBSyxDQUFDRSxNQUFNO0lBQUM7SUFDdENFLFFBQVE7UUFBRUwsTUFBTUwsNENBQU1BLENBQUNNLEtBQUssQ0FBQ0UsTUFBTTtJQUFDO0lBQ3BDRyxRQUFRO1FBQUVOLE1BQU1MLDRDQUFNQSxDQUFDTSxLQUFLLENBQUNFLE1BQU07UUFBRUksU0FBUztJQUFTO0lBQ3ZEQyxZQUFZO1FBQUVSLE1BQU1MLDRDQUFNQSxDQUFDTSxLQUFLLENBQUNRLElBQUk7UUFBRUYsU0FBUyxJQUFJRTtJQUFPO0lBQzNEQyxZQUFZO1FBQUVWLE1BQU1MLDRDQUFNQSxDQUFDTSxLQUFLLENBQUNRLElBQUk7UUFBRUYsU0FBUyxJQUFJRTtJQUFPO0lBQzNERSxZQUFZO1FBQUVYLE1BQU1MLDRDQUFNQSxDQUFDTSxLQUFLLENBQUNFLE1BQU07SUFBQztJQUN4Q1MsVUFBVTtRQUFFWixNQUFNTCw0Q0FBTUEsQ0FBQ00sS0FBSyxDQUFDRSxNQUFNO0lBQUM7QUFDeEM7QUFFQSxpRUFBZU4sNENBQU1BLENBQUNnQixRQUFRLElBQUlqQiwrQ0FBS0EsQ0FBQyxZQUFZRSxvQkFBb0JBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zdHJpcGUtcGF5bWVudC8uL3NyYy9tb2RlbHMvZG9uYXRpb24tbW9kZWwtc2NoZW1hLnRzPzAwZjgiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRG9jdW1lbnQsIE1vZGVsLCBTY2hlbWEsIG1vZGVsLCBtb2RlbHMsIFR5cGVzLCBNaXhlZCB9IGZyb20gXCJtb25nb29zZVwiO1xyXG5cclxuaW50ZXJmYWNlIElEb25hdGlvbiBleHRlbmRzIERvY3VtZW50IHtcclxuICB6b25lX2lkOiBTY2hlbWEuVHlwZXMuT2JqZWN0SWQ7XHJcbiAgdHlwZTogc3RyaW5nO1xyXG4gIGN1cnJlbmN5OiBzdHJpbmc7XHJcbiAgYW1vdW50OiBzdHJpbmc7XHJcbiAgc3RhdHVzOiBzdHJpbmc7XHJcbiAgY3JlYXRlZF9hdDogRGF0ZTtcclxuICB1cGRhdGVkX2F0OiBEYXRlO1xyXG4gIHByb2R1Y3RfaWQ6IHN0cmluZztcclxuICBwcmljZV9pZDogc3RyaW5nO1xyXG59XHJcblxyXG50eXBlIERvbmF0aW9uTW9kZWwgPSBNb2RlbDxJRG9uYXRpb24+O1xyXG5cclxuY29uc3QgRG9uYXRpb25Nb2RlbFNjaGVtYSA9IG5ldyBTY2hlbWE8SURvbmF0aW9uLCBEb25hdGlvbk1vZGVsPih7XHJcbiAgem9uZV9pZDogeyB0eXBlOiBTY2hlbWEuVHlwZXMuT2JqZWN0SWQgfSxcclxuICB0eXBlOiB7IHR5cGU6IFNjaGVtYS5UeXBlcy5TdHJpbmcgfSxcclxuICBjdXJyZW5jeTogeyB0eXBlOiBTY2hlbWEuVHlwZXMuU3RyaW5nIH0sXHJcbiAgYW1vdW50OiB7IHR5cGU6IFNjaGVtYS5UeXBlcy5TdHJpbmcgfSxcclxuICBzdGF0dXM6IHsgdHlwZTogU2NoZW1hLlR5cGVzLlN0cmluZywgZGVmYXVsdDogXCJFTkFCTEVcIiB9LFxyXG4gIGNyZWF0ZWRfYXQ6IHsgdHlwZTogU2NoZW1hLlR5cGVzLkRhdGUsIGRlZmF1bHQ6IG5ldyBEYXRlKCkgfSxcclxuICB1cGRhdGVkX2F0OiB7IHR5cGU6IFNjaGVtYS5UeXBlcy5EYXRlLCBkZWZhdWx0OiBuZXcgRGF0ZSgpIH0sXHJcbiAgcHJvZHVjdF9pZDogeyB0eXBlOiBTY2hlbWEuVHlwZXMuU3RyaW5nIH0sXHJcbiAgcHJpY2VfaWQ6IHsgdHlwZTogU2NoZW1hLlR5cGVzLlN0cmluZyB9LFxyXG59KTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IG1vZGVscy5kb25hdGlvbiB8fCBtb2RlbChcImRvbmF0aW9uXCIsIERvbmF0aW9uTW9kZWxTY2hlbWEpO1xyXG4iXSwibmFtZXMiOlsiU2NoZW1hIiwibW9kZWwiLCJtb2RlbHMiLCJEb25hdGlvbk1vZGVsU2NoZW1hIiwiem9uZV9pZCIsInR5cGUiLCJUeXBlcyIsIk9iamVjdElkIiwiU3RyaW5nIiwiY3VycmVuY3kiLCJhbW91bnQiLCJzdGF0dXMiLCJkZWZhdWx0IiwiY3JlYXRlZF9hdCIsIkRhdGUiLCJ1cGRhdGVkX2F0IiwicHJvZHVjdF9pZCIsInByaWNlX2lkIiwiZG9uYXRpb24iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./src/models/donation-model-schema.ts\n");

/***/ }),

/***/ "(api)/./src/pages/api/donation/index.ts":
/*!*****************************************!*\
  !*** ./src/pages/api/donation/index.ts ***!
  \*****************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _middleware_db_middleware__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/middleware/db-middleware */ \"(api)/./src/middleware/db-middleware.ts\");\n/* harmony import */ var _models_donation_model_schema__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/models/donation-model-schema */ \"(api)/./src/models/donation-model-schema.ts\");\n/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next-connect */ \"next-connect\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_2__]);\nnext_connect__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n// import dbMiddleware from \"@/middleware/dbMiddleware\";\n\n\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_connect__WEBPACK_IMPORTED_MODULE_2__[\"default\"])().use(_middleware_db_middleware__WEBPACK_IMPORTED_MODULE_0__[\"default\"]).get(async (req, res)=>{\n    try {\n        const donation = await _models_donation_model_schema__WEBPACK_IMPORTED_MODULE_1__[\"default\"].find({});\n        return res.status(200).json(donation);\n    } catch (error) {}\n}));\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9zcmMvcGFnZXMvYXBpL2RvbmF0aW9uL2luZGV4LnRzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSx3REFBd0Q7QUFFRjtBQUNXO0FBRTFCO0FBRXZDLGlFQUFlRSx3REFBV0EsR0FDdkJDLEdBQUcsQ0FBQ0gsaUVBQVlBLEVBQ2hCSSxHQUFHLENBQUMsT0FBT0MsS0FBcUJDO0lBQy9CLElBQUk7UUFDRixNQUFNQyxXQUFXLE1BQU1OLDBFQUF3QixDQUFDLENBQUM7UUFDakQsT0FBT0ssSUFBSUcsTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQ0g7SUFDOUIsRUFBRSxPQUFPSSxPQUFPLENBQUM7QUFDbkIsRUFBRSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vc3RyaXBlLXBheW1lbnQvLi9zcmMvcGFnZXMvYXBpL2RvbmF0aW9uL2luZGV4LnRzPzMyMDciXSwic291cmNlc0NvbnRlbnQiOlsiLy8gaW1wb3J0IGRiTWlkZGxld2FyZSBmcm9tIFwiQC9taWRkbGV3YXJlL2RiTWlkZGxld2FyZVwiO1xyXG5cclxuaW1wb3J0IGRiTWlkZGxld2FyZSBmcm9tIFwiQC9taWRkbGV3YXJlL2RiLW1pZGRsZXdhcmVcIjtcclxuaW1wb3J0IGRvbmF0aW9uTW9kZWxTY2hlbWEgZnJvbSBcIkAvbW9kZWxzL2RvbmF0aW9uLW1vZGVsLXNjaGVtYVwiO1xyXG5pbXBvcnQgeyBOZXh0QXBpUmVxdWVzdCwgTmV4dEFwaVJlc3BvbnNlIH0gZnJvbSBcIm5leHRcIjtcclxuaW1wb3J0IG5leHRDb25uZWN0IGZyb20gXCJuZXh0LWNvbm5lY3RcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IG5leHRDb25uZWN0KClcclxuICAudXNlKGRiTWlkZGxld2FyZSlcclxuICAuZ2V0KGFzeW5jIChyZXE6IE5leHRBcGlSZXF1ZXN0LCByZXM6IE5leHRBcGlSZXNwb25zZSkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgZG9uYXRpb24gPSBhd2FpdCBkb25hdGlvbk1vZGVsU2NoZW1hLmZpbmQoe30pO1xyXG4gICAgICByZXR1cm4gcmVzLnN0YXR1cygyMDApLmpzb24oZG9uYXRpb24pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHt9XHJcbiAgfSk7XHJcbiJdLCJuYW1lcyI6WyJkYk1pZGRsZXdhcmUiLCJkb25hdGlvbk1vZGVsU2NoZW1hIiwibmV4dENvbm5lY3QiLCJ1c2UiLCJnZXQiLCJyZXEiLCJyZXMiLCJkb25hdGlvbiIsImZpbmQiLCJzdGF0dXMiLCJqc29uIiwiZXJyb3IiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./src/pages/api/donation/index.ts\n");

/***/ }),

/***/ "(api)/./src/utils/db-connect.ts":
/*!*********************************!*\
  !*** ./src/utils/db-connect.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\n//mongoose.set('debug', true);\nlet conn = null;\nasync function dbConnect() {\n    // check if we have a connection to the database or if it's currently\n    // connecting or disconnecting (readyState 1, 2 and 3)\n    if (conn == null) {\n        conn = mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGODB_URI, {\n            serverSelectionTimeoutMS: 5000\n        }).then(()=>(mongoose__WEBPACK_IMPORTED_MODULE_0___default()));\n        // `await`ing connection after assigning to the `conn` variable\n        // to avoid multiple function calls creating new connections\n        await conn;\n    }\n    return conn;\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dbConnect);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9zcmMvdXRpbHMvZGItY29ubmVjdC50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBZ0M7QUFDaEMsOEJBQThCO0FBQzlCLElBQUlDLE9BQVk7QUFFaEIsZUFBZUM7SUFDYixxRUFBcUU7SUFDckUsc0RBQXNEO0lBQ3RELElBQUlELFFBQVEsTUFBTTtRQUNoQkEsT0FBT0QsdURBQ0csQ0FBQ0ksUUFBUUMsR0FBRyxDQUFDQyxXQUFXLEVBQUc7WUFDakNDLDBCQUEwQjtRQUM1QixHQUNDQyxJQUFJLENBQUMsSUFBTVIsaURBQVFBO1FBRXRCLCtEQUErRDtRQUMvRCw0REFBNEQ7UUFDNUQsTUFBTUM7SUFDUjtJQUVBLE9BQU9BO0FBQ1Q7QUFFQSxpRUFBZUMsU0FBU0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3N0cmlwZS1wYXltZW50Ly4vc3JjL3V0aWxzL2RiLWNvbm5lY3QudHM/NDM4NSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbW9uZ29vc2UgZnJvbSBcIm1vbmdvb3NlXCI7XHJcbi8vbW9uZ29vc2Uuc2V0KCdkZWJ1ZycsIHRydWUpO1xyXG5sZXQgY29ubjogYW55ID0gbnVsbDtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGRiQ29ubmVjdCgpIHtcclxuICAvLyBjaGVjayBpZiB3ZSBoYXZlIGEgY29ubmVjdGlvbiB0byB0aGUgZGF0YWJhc2Ugb3IgaWYgaXQncyBjdXJyZW50bHlcclxuICAvLyBjb25uZWN0aW5nIG9yIGRpc2Nvbm5lY3RpbmcgKHJlYWR5U3RhdGUgMSwgMiBhbmQgMylcclxuICBpZiAoY29ubiA9PSBudWxsKSB7XHJcbiAgICBjb25uID0gbW9uZ29vc2VcclxuICAgICAgLmNvbm5lY3QocHJvY2Vzcy5lbnYuTU9OR09EQl9VUkkhLCB7XHJcbiAgICAgICAgc2VydmVyU2VsZWN0aW9uVGltZW91dE1TOiA1MDAwLFxyXG4gICAgICB9KVxyXG4gICAgICAudGhlbigoKSA9PiBtb25nb29zZSk7XHJcblxyXG4gICAgLy8gYGF3YWl0YGluZyBjb25uZWN0aW9uIGFmdGVyIGFzc2lnbmluZyB0byB0aGUgYGNvbm5gIHZhcmlhYmxlXHJcbiAgICAvLyB0byBhdm9pZCBtdWx0aXBsZSBmdW5jdGlvbiBjYWxscyBjcmVhdGluZyBuZXcgY29ubmVjdGlvbnNcclxuICAgIGF3YWl0IGNvbm47XHJcbiAgfVxyXG5cclxuICByZXR1cm4gY29ubjtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZGJDb25uZWN0O1xyXG4iXSwibmFtZXMiOlsibW9uZ29vc2UiLCJjb25uIiwiZGJDb25uZWN0IiwiY29ubmVjdCIsInByb2Nlc3MiLCJlbnYiLCJNT05HT0RCX1VSSSIsInNlcnZlclNlbGVjdGlvblRpbWVvdXRNUyIsInRoZW4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./src/utils/db-connect.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./src/pages/api/donation/index.ts"));
module.exports = __webpack_exports__;

})();